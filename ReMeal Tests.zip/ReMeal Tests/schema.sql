-- Create the remeal database
CREATE DATABASE  remeal;
USE remeal;

-- Create the users table
CREATE TABLE  users (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255),
    email VARCHAR(255),
    password VARCHAR(255),
    ort VARCHAR(255)
);

-- Create the posts table
CREATE TABLE  posts (
    postID INT AUTO_INCREMENT PRIMARY KEY,
    titel VARCHAR(255),
    beschreibung VARCHAR(255),
    ort VARCHAR(255),
    tags VARCHAR(255),
    ersteller VARCHAR(255),
    erstellerID INT,
    datum VARCHAR(255),
    FOREIGN KEY (erstellerID) REFERENCES users(userID)
);

-- Insert sample data into the users table
INSERT INTO users (username, email, password, ort)
VALUES
    ('luke', 'luke@remeal.com', 'test1', 'Burscheid'),
    ('milo', 'milo@remeal.com', 'test2', 'Hüscheid');