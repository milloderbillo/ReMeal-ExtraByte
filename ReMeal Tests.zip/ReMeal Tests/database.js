import mysql from 'mysql2'

import dotenv from 'dotenv'
dotenv.config()

const pool = mysql.createPool({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE
}).promise()


export async function getUsers(){

const [rows] = await pool.query("SELECT * FROM users")
return rows

}

export async function getUser(username){
    
    const [rows] = await pool.query(`
    SELECT * 
    FROM users
    WHERE username = ?
    `, [username])
    return rows
    
    }

    export async function addUser(userID, username, email, password, ort) {
        const [result] = await pool.query(
          `INSERT INTO users (userID, username, email, password, ort)
          VALUES (?, ?, ?, ?, ?)`,
          [userID, username, email, password, ort]
        );
        return result;
      }


      export async function getPosts(){

        const [rows] = await pool.query("SELECT * FROM posts")
        return rows
        
        }
        
        export async function getPost(ersteller){
            
            const [rows] = await pool.query(`
            SELECT * 
            FROM posts
            WHERE ersteller = ?
            `, [ersteller])
            return rows
            
            }
        
            export async function addPost(postID, titel, beschreibung, ort, tags, ersteller, erstellerID, datum) {
              const formattedDatum = new Date(datum).toISOString().slice(0, 19).replace('T', ' ');
            
              const [result] = await pool.query(
                `INSERT INTO posts (postID, titel, beschreibung, ort, tags, ersteller, erstellerID, datum)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [postID, titel, beschreibung, ort, tags, ersteller, erstellerID, formattedDatum]
              );
              return result;
            }
