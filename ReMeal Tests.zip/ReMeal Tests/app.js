import express from 'express'

import { getUsers, getUser, addUser, getPosts, getPost, addPost } from './database.js'
import e from 'express'

const app = express()

app.use(express.json())


app.get("/users", async (req, res) => {
    const users = await getUsers()
    res.send(users)
})

app.get("/users/:username", async (req, res) => {
    const username = req.params.username
    const users = await getUser(username)
    res.send(users)
})

app.post("/users", async (req, res) => {
    const {userID, username, email, password, ort } = req.body
    const user = await addUser(userID, username, email, password, ort)
    res.status(201).send(user)
})


app.get("/posts", async (req, res) => {
    const posts = await getPosts()
    res.send(posts)
})

app.get("/posts/:ersteller", async (req, res) => {
    const post = req.params.ersteller;
    const posts = await getPost(post);
    res.send(posts);
  });

  app.post("/posts", async (req, res) => {
    const { postID, titel, beschreibung, ort, tags, ersteller, erstellerID, datum } = req.body;
    const post = await addPost(postID, titel, beschreibung, ort, tags, ersteller, erstellerID, datum);
    res.status(201).send(post);
  });

app.use((err, req, res, next) => {
    console.error(err.stack)
    res.status(500).send('Something broke!')
})


app.listen(8080, () =>{
    console.log('Server is running')
})